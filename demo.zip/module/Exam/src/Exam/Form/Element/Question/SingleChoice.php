<?php
namespace Exam\Form\Element\Question;

class SingleChoice extends MultipleChoice
{
    protected $maxAnswers = 1;
}
