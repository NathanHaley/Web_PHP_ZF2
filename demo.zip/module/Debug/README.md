This module provides debug information about your application.
Take a look at the config/module.config.php and config/debug.global.php.dist files to see how to customize this module for your needs.
