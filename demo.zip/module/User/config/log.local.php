<?php

return array(
    'log' => array(
        'priority' => \Zend\Log\Logger::WARN,
    )
);
