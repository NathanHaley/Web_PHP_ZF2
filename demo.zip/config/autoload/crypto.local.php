<?php
return array(
    'cipher' => array(
        'adapter' => 'mcrypt',
        'options' => array(
                'algo' => 'aes'
        ),
        'encryption_key' => '<ENTER-HERE-VERY-LONG-ENCRYPTION-KEY>',
    ),
    'bcrypt' => array(
        'cost' => 16
    )
);
