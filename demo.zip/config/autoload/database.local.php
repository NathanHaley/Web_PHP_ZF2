<?php
return array(
    'db' => array(
        'driver' => 'Pdo_Mysql',
        'database' => 'tc',
        'username' => 'tc',
        'password' => 'bh2bh2',
        'hostname' => 'localhost',
        'charset'  => 'utf8'
    )
);
